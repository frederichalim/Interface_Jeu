package Main;

import Model.Lettres;
import View.ViewHandler;
import javafx.application.Application;

public class Main {

    public static void main(String[] args) {
        Application.launch(ViewHandler.class);


    }
}
