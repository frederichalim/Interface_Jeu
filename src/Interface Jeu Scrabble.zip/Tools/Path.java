package Tools;

public class Path {
    public static final String fondMenu = "Asset/Images/scrabble.jpg";
    public static final String fondMenu1 = "Asset/Images/scrabble2.png";
    public static final String fontsGothic = "../Asset/fonts/TaylorGothic.otf";
    public static final String fontsVladimir = "../Asset/fonts/VLADIMIR.TTF";

}
