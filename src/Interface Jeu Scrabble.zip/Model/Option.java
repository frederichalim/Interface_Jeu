package Model;

public class Option {
}
